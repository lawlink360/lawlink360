import 'dart:io';

import 'package:flutter/material.dart';
import '../widgets/document_crop_painter.dart';

class DocumentCropScreen extends StatefulWidget {
  final String imagePath;

  const DocumentCropScreen({
    super.key,
    required this.imagePath,
  });

  @override
  State<DocumentCropScreen> createState() => _DocumentCropScreenState();
}

class _DocumentCropScreenState extends State<DocumentCropScreen> {
  Offset topLeft = const Offset(40, 60);
  Offset topRight = const Offset(320, 60);
  Offset bottomLeft = const Offset(40, 520);
  Offset bottomRight = const Offset(320, 520);

  static const double handleRadius = 14;

  Widget buildHandle(
    Offset position,
    Function(Offset) onChanged,
  ) {
    return Positioned(
      left: position.dx - handleRadius,
      top: position.dy - handleRadius,
      child: GestureDetector(
        onPanUpdate: (details) {
          onChanged(
            Offset(
              position.dx + details.delta.dx,
              position.dy + details.delta.dy,
            ),
          );
        },
        child: Container(
          width: handleRadius * 2,
          height: handleRadius * 2,
          decoration: const BoxDecoration(
            color: Color(0xFFD4AF37),
            shape: BoxShape.circle,
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,

      appBar: AppBar(
        backgroundColor: Colors.black,
        title: const Text("Crop Document"),
      ),

      body: LayoutBuilder(
        builder: (context, constraints) {
          return Stack(
            children: [
              Center(
                child: Image.file(
                  File(widget.imagePath),
                  fit: BoxFit.contain,
                ),
              ),

              CustomPaint(
                size: Size(
                  constraints.maxWidth,
                  constraints.maxHeight,
                ),
                painter: DocumentCropPainter(
                  topLeft: topLeft,
                  topRight: topRight,
                  bottomLeft: bottomLeft,
                  bottomRight: bottomRight,
                ),
              ),
              buildHandle(
                topLeft,
                (value) {
                  setState(() {
                    topLeft = value;
                  });
                },
              ),

              buildHandle(
                topRight,
                (value) {
                  setState(() {
                    topRight = value;
                  });
                },
              ),

              buildHandle(
                bottomLeft,
                (value) {
                  setState(() {
                    bottomLeft = value;
                  });
                },
              ),

              buildHandle(
                bottomRight,
                (value) {
                  setState(() {
                    bottomRight = value;
                  });
                },
              ),
            ],
          );
        },
      ),

      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(20),
        child: SizedBox(
          height: 55,
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFD4AF37),
              foregroundColor: Colors.black,
            ),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text(
                    "Perspective crop will be implemented in next step.",
                  ),
                ),
              );
            },
            child: const Text(
              "Apply Crop",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ),
    );
  }
}