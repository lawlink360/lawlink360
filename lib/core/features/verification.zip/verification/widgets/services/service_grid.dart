import 'package:flutter/material.dart';

import '../../models/verification_service.dart';
import '../../services/verification_data_service.dart';
import '../../screens/verification_webview_screen.dart';
import 'service_card.dart';

class ServiceGrid extends StatelessWidget {
  final String institutionId;

  const ServiceGrid({
    super.key,
    required this.institutionId,
  });

  @override
  Widget build(BuildContext context) {
    final services =
        VerificationDataService.getServicesByInstitution(
      institutionId,
    );

    return ListView.builder(
      padding: const EdgeInsets.only(bottom: 30),
      itemCount: services.length,
      itemBuilder: (context, index) {
        final service = services[index];

        return ServiceCard(
          icon: service.icon,
          color: service.color,
          title: service.title,
          description: service.description,
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => VerificationWebViewScreen(
                  title: service.title,
                  url: service.websiteUrl,
                ),
              ),
            );
          },
        );
      },
    );
  }
}