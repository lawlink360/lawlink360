import 'package:flutter/material.dart';

import '../../models/verification_category.dart';
import 'package:lawlink360/core/features/verification/models/verification_subcategory.dart';

import '../../services/verification_data_service.dart';
import '../../screens/subcategory_screen.dart';
import 'package:lawlink360/core/features/verification/widgets/subcategory/subcatagory_card.dart';


class SubCategoryGrid extends StatelessWidget {
  final VerificationCategory category;

  const SubCategoryGrid({
    super.key,
    required this.category,
  });

  @override
  Widget build(BuildContext context) {
    final subCategories =
        VerificationDataService.getSubCategories(category.id);

    return ListView.builder(
      padding: const EdgeInsets.only(bottom: 30),
      itemCount: subCategories.length,
      itemBuilder: (context, index) {
        final subCategory = subCategories[index];

        return SubCategoryCard(
          subCategory: subCategory,
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => SubCategoryScreen(
                  subCategory: subCategory,
                ),
              ),
            );
          },
        );
      },
    );
  }
}