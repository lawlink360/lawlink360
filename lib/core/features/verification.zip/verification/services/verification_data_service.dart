import 'package:flutter/material.dart';

import '../models/verification_category.dart';
import '../models/verification_subcategory.dart';
import '../models/verification_institution.dart';
import '../models/verification_service.dart';

class VerificationDataService {
  /// ==========================
  /// VERIFICATION CATEGORIES
  /// ==========================

  static const List<VerificationCategory> categories = [
    VerificationCategory(
      id: 'courts',
      title: 'Courts',
      description: 'Supreme Court & High Courts',
      icon: Icons.account_balance_rounded,
      color: Color(0xFF2563EB),
    ),

    VerificationCategory(
      id: 'lawyers',
      title: 'Lawyers',
      description: 'Bar Councils & Advocates',
      icon: Icons.gavel_rounded,
      color: Color(0xFFF59E0B),
    ),

    VerificationCategory(
      id: 'property',
      title: 'Property',
      description: 'Land & Revenue Records',
      icon: Icons.home_work_rounded,
      color: Color(0xFF10B981),
    ),

    VerificationCategory(
      id: 'government',
      title: 'Government',
      description: 'Official Government Services',
      icon: Icons.apartment_rounded,
      color: Color(0xFF8B5CF6),
    ),

    VerificationCategory(
      id: 'police',
      title: 'Police',
      description: 'Police Verification',
      icon: Icons.local_police_rounded,
      color: Color(0xFFEF4444),
    ),

    VerificationCategory(
      id: 'business',
      title: 'Business',
      description: 'SECP & Business Records',
      icon: Icons.business_center_rounded,
      color: Color(0xFF0EA5E9),
    ),

    VerificationCategory(
      id: 'education',
      title: 'Education',
      description: 'Degrees & Universities',
      icon: Icons.school_rounded,
      color: Color(0xFF14B8A6),
    ),

    VerificationCategory(
      id: 'documents',
      title: 'Documents',
      description: 'Official Document Services',
      icon: Icons.description_rounded,
      color: Color(0xFFD97706),
    ),
  ];

  /// ==========================
  /// VERIFICATION SUB CATEGORIES
  /// ==========================

  static const List<VerificationSubCategory> subCategories = [
    /// ================= COURTS =================
    VerificationSubCategory(
      id: 'supreme_courts',
      categoryId: 'courts',
      title: 'Supreme Courts',
      description: 'Supreme Courts of Pakistan',
      icon: Icons.gavel_rounded,
      color: Color(0xFF2563EB),
      institutionCount: 2,
    ),

    VerificationSubCategory(
      id: 'federal_shariat',
      categoryId: 'courts',
      title: 'Federal Shariat Court',
      description: 'Federal Shariat Court',
      icon: Icons.balance_rounded,
      color: Color(0xFF2563EB),
      institutionCount: 1,
    ),

    VerificationSubCategory(
      id: 'high_courts',
      categoryId: 'courts',
      title: 'High Courts',
      description: 'All High Courts of Pakistan',
      icon: Icons.account_balance_rounded,
      color: Color(0xFF2563EB),
      institutionCount: 7,
    ),

    VerificationSubCategory(
      id: 'district_courts',
      categoryId: 'courts',
      title: 'District Courts',
      description: 'District Judiciary',
      icon: Icons.gavel,
      color: Color(0xFF2563EB),
      institutionCount: 5,
    ),

    VerificationSubCategory(
      id: 'judicial_academies',
      categoryId: 'courts',
      title: 'Judicial Academies',
      description: 'Judicial Training Institutes',
      icon: Icons.school_rounded,
      color: Color(0xFF2563EB),
      institutionCount: 5,
    ),

    VerificationSubCategory(
      id: 'tribunals',
      categoryId: 'courts',
      title: 'Tribunals',
      description: 'Special Courts & Tribunals',
      icon: Icons.account_balance_wallet_rounded,
      color: Color(0xFF2563EB),
      institutionCount: 8,
    ),
  ];

  /// ==========================
  /// VERIFICATION INSTITUTIONS
  /// ==========================

  static const List<VerificationInstitution> institutions = [
    /// Supreme Courts
    VerificationInstitution(
      id: 'supreme_court_pakistan',
      categoryId: 'courts',
      subCategoryId: 'supreme_courts',
      title: 'Supreme Court of Pakistan',
      description: 'Supreme Judicial Authority',
      icon: Icons.gavel_rounded,
      color: Color(0xFF2563EB),
      serviceCount: 6,
    ),

    VerificationInstitution(
      id: 'federal_shariat_court',
      categoryId: 'courts',
      subCategoryId: 'federal_shariat',
      title: 'Federal Shariat Court',
      description: 'Federal Shariat Court of Pakistan',
      icon: Icons.balance_rounded,
      color: Color(0xFF2563EB),
      serviceCount: 5,
    ),

    /// High Courts
    VerificationInstitution(
      id: 'lahore_high_court',
      categoryId: 'courts',
      subCategoryId: 'high_courts',
      title: 'Lahore High Court',
      description: 'Lahore High Court',
      icon: Icons.account_balance_rounded,
      color: Color(0xFF2563EB),
      serviceCount: 8,
    ),

    VerificationInstitution(
      id: 'islamabad_high_court',
      categoryId: 'courts',
      subCategoryId: 'high_courts',
      title: 'Islamabad High Court',
      description: 'Islamabad High Court',
      icon: Icons.account_balance_rounded,
      color: Color(0xFF2563EB),
      serviceCount: 8,
    ),

    VerificationInstitution(
      id: 'sindh_high_court',
      categoryId: 'courts',
      subCategoryId: 'high_courts',
      title: 'Sindh High Court',
      description: 'Sindh High Court',
      icon: Icons.account_balance_rounded,
      color: Color(0xFF2563EB),
      serviceCount: 8,
    ),

    VerificationInstitution(
      id: 'peshawar_high_court',
      categoryId: 'courts',
      subCategoryId: 'high_courts',
      title: 'Peshawar High Court',
      description: 'Peshawar High Court',
      icon: Icons.account_balance_rounded,
      color: Color(0xFF2563EB),
      serviceCount: 8,
    ),

    VerificationInstitution(
      id: 'balochistan_high_court',
      categoryId: 'courts',
      subCategoryId: 'high_courts',
      title: 'Balochistan High Court',
      description: 'Balochistan High Court',
      icon: Icons.account_balance_rounded,
      color: Color(0xFF2563EB),
      serviceCount: 8,
    ),
  ];

  /// ==========================
  /// VERIFICATION SERVICES
  /// ==========================

  static const List<VerificationService> services = [
    // ================= Lahore High Court =================
    VerificationService(
      id: 'lhc_official',
      categoryId: 'courts',
      subCategoryId: 'high_courts',
      institutionId: 'lahore_high_court',
      title: 'Official Website',
      description: 'Visit Lahore High Court official website',
      authority: 'Lahore High Court',
      websiteUrl: 'https://lhc.gov.pk/',
      icon: Icons.language_rounded,
      color: Color(0xFF2563EB),
      isPopular: true,
    ),

    VerificationService(
      id: 'lhc_case_management',
      categoryId: 'courts',
      subCategoryId: 'high_courts',
      institutionId: 'lahore_high_court',
      title: 'Case Management',
      description: 'Search and track your case',
      authority: 'Lahore High Court',
      websiteUrl: 'https://lhc.gov.pk/case_management',
      icon: Icons.search_rounded,
      color: Color(0xFF2563EB),
    ),

    VerificationService(
      id: 'lhc_biometric',
      categoryId: 'courts',
      subCategoryId: 'high_courts',
      institutionId: 'lahore_high_court',
      title: 'Biometric Verification',
      description: 'Lawyer biometric verification',
      authority: 'Lahore High Court',
      websiteUrl: 'https://biosystid.lhc.gov.pk/biosystno',
      icon: Icons.fingerprint_rounded,
      color: Color(0xFF2563EB),
    ),

    // ================= Islamabad High Court =================
    VerificationService(
      id: 'ihc_official',
      categoryId: 'courts',
      subCategoryId: 'high_courts',
      institutionId: 'islamabad_high_court',
      title: 'Official Website',
      description: 'Visit Islamabad High Court',
      authority: 'Islamabad High Court',
      websiteUrl: 'https://ihc.gov.pk/',
      icon: Icons.language_rounded,
      color: Color(0xFF2563EB),
    ),

    // ================= Sindh High Court =================
    VerificationService(
      id: 'shc_case_search',
      categoryId: 'courts',
      subCategoryId: 'high_courts',
      institutionId: 'sindh_high_court',
      title: 'Case Search',
      description: 'Search Sindh High Court cases',
      authority: 'Sindh High Court',
      websiteUrl: 'https://cases.shc.gov.pk/',
      icon: Icons.search_rounded,
      color: Color(0xFF2563EB),
    ),

    // ================= Peshawar High Court =================
    VerificationService(
      id: 'phc_official',
      categoryId: 'courts',
      subCategoryId: 'high_courts',
      institutionId: 'peshawar_high_court',
      title: 'Official Website',
      description: 'Visit Peshawar High Court',
      authority: 'Peshawar High Court',
      websiteUrl: 'https://www.peshawarhighcourt.gov.pk/app/site/',
      icon: Icons.language_rounded,
      color: Color(0xFF2563EB),
    ),

    VerificationService(
      id: 'phc_cfmis',
      categoryId: 'courts',
      subCategoryId: 'high_courts',
      institutionId: 'peshawar_high_court',
      title: 'CFMIS Case Search',
      description: 'District judiciary case search',
      authority: 'Peshawar High Court',
      websiteUrl: 'https://cfmisdcportal.peshawarhighcourt.gov.pk/',
      icon: Icons.search_rounded,
      color: Color(0xFF2563EB),
    ),

    // ================= Balochistan High Court =================
    VerificationService(
      id: 'bhc_cause_list',
      categoryId: 'courts',
      subCategoryId: 'high_courts',
      institutionId: 'balochistan_high_court',
      title: 'Cause Lists',
      description: 'Daily cause lists',
      authority: 'High Court of Balochistan',
      websiteUrl: 'https://portal.bhc.gov.pk/dj-case-status/',
      icon: Icons.list_alt_rounded,
      color: Color(0xFF2563EB),
    ),

    // ================= Supreme Court of Pakistan =================
    VerificationService(
      id: 'scp_case_status',
      categoryId: 'courts',
      subCategoryId: 'supreme_courts',
      institutionId: 'supreme_court_pakistan',
      title: 'Online Case Status',
      description: 'Search Supreme Court cases',
      authority: 'Supreme Court of Pakistan',
      websiteUrl: 'https://share.google/kW0RR38RRFn6PpAok',
      icon: Icons.search_rounded,
      color: Color(0xFF2563EB),
      isPopular: true,
    ),

    // ================= Federal Special Courts =================
    VerificationService(
      id: 'special_courts',
      categoryId: 'courts',
      subCategoryId: 'tribunals',
      institutionId: 'federal_special_courts',
      title: 'Cases Search',
      description: 'Federal Special Courts & Tribunals',
      authority: 'Government of Pakistan',
      websiteUrl: 'https://share.google/xPkmtqJ0Rni2DwZkF',
      icon: Icons.gavel_rounded,
      color: Color(0xFF2563EB),
    ),

    // ================= Punjab District Judiciary =================
    VerificationService(
      id: 'district_case_management',
      categoryId: 'courts',
      subCategoryId: 'district_courts',
      institutionId: 'punjab_district_judiciary',
      title: 'Case Management',
      description: 'District Judiciary Punjab',
      authority: 'District Judiciary Punjab',
      websiteUrl: 'https://share.google/zPdUed9cpJIOf9RCo',
      icon: Icons.account_balance_rounded,
      color: Color(0xFF2563EB),
    ),
  ];

    /// ==========================
  /// GET CATEGORY BY ID
  /// ==========================

  static VerificationCategory? getCategory(String id) {
    try {
      return categories.firstWhere((category) => category.id == id);
    } catch (_) {
      return null;
    }
  }

  /// ==========================
  /// GET SUB CATEGORIES
  /// ==========================

  static List<VerificationSubCategory> getSubCategories(String categoryId) {
    return subCategories
        .where((item) => item.categoryId == categoryId)
        .toList();
  }

  /// ==========================
  /// GET INSTITUTIONS
  /// ==========================

  static List<VerificationInstitution> getInstitutions(String subCategoryId) {
    return institutions
        .where((item) => item.subCategoryId == subCategoryId)
        .toList();
  }

  /// ==========================
  /// GET SERVICES
  /// ==========================

  static List<VerificationService> getServices(String institutionId) {
    return services
        .where((item) => item.institutionId == institutionId)
        .toList();
  }

}
