import 'package:flutter/material.dart';
import '../models/verification_institution.dart';
import '../widgets/institution/institution_header.dart';

class InstitutionScreen extends StatelessWidget {
  final VerificationInstitution institution;

  const InstitutionScreen({
    super.key,
    required this.institution,
  });

  @override
Widget build(BuildContext context) {
  return Scaffold(
    backgroundColor: const Color(0xFFF8FAFC),
    body: Column(
      children: [

        /// Header
        InstitutionHeader(
          institution: institution,
        ),

        /// Services
        Expanded(
          child: Center(
            child: Text(
              "Services will appear here",
              style: TextStyle(
                fontSize: 18,
                color: Colors.grey.shade700,
              ),
            ),
          ),
        ),
      ],
    ),
  );
}
}
